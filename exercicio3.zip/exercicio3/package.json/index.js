const colors = require('colors');

console.log('🍞 Bem-vindo à Padaria do João!'.rainbow);
console.log('Pães frescos todos os dias!'.green);
console.log('Horário: 6h às 18h'.blue);
